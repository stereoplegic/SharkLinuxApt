#!/bin/bash
shark-install sharkqlc
sudo mv /usr/share/SharkLinux/qlc.desktop ~/.local/share/applications

