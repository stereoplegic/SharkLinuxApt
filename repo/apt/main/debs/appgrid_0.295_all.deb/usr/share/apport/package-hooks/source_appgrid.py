# -*- coding: utf-8 -*-
# This code is copyrighted and all rights are reserved
# for full legalities see the LEGAL file


def add_info(report):
    report['CrashDB'] = '{"impl": "launchpad", "project": "appgrid"}'
