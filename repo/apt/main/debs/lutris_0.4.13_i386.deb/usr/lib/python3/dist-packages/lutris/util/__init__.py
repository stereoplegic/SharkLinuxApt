""" Misc common functions """
